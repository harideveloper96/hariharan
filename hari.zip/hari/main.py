cars=[5,6,3,6,2,1]
cars.reverse()
print(cars)